/* Grupo 48
 *   Eva Gomes (37806)
 *   João Santos (40335)
 *   João Vieira (45677)
 */
#ifndef _DATA_PRIVATE_H
#define _DATA_PRIVATE_H

void* copy(void* something, int size);

#endif
