/* Grupo 48
 *   Eva Gomes (37806)
 *   João Santos (40335)
 *   João Vieira (45677)
 */
#ifndef _ENTRY_PRIVATE_H
#define _ENTRY_PRIVATE_H

int key_compare(char* key1, char* key2);

#endif
