# sdistr2020-group48-proj2


## Known limitations:
- Tree does not balance itself when inserting new nodes.
- (solved) ~~Serialization of entries does not handle entries with null keys or null values.~~
- (solved) ~~Serialization of trees does not handle entries with null keys or null values.~~
- Does not use standard error handling ("errno" and "perror").
- Makes use of read/write functions (to be replaced with custom read_all/write_all).
- Doesn't work :(