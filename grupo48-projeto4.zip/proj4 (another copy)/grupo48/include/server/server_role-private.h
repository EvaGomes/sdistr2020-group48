/* Grupo 48
 *   Eva Gomes (37806)
 *   João Santos (40335)
 *   João Vieira (45677)
 */
#ifndef _SERVER_ROLE_PRIVATE_H
#define _SERVER_ROLE_PRIVATE_H

enum ServerRole {
  PRIMARY = 1,
  BACKUP = 2,

  NONE = -1
};

#endif
